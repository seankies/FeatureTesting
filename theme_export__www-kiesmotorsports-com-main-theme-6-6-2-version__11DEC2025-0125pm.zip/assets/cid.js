document.addEventListener('DOMContentLoaded', function () {
    const syncInchesWithMM = (inchesInput, mmInput) => {
        inchesInput.addEventListener('input', function () {
            const inches = parseFloat(inchesInput.value);
            mmInput.value = isNaN(inches) ? '' : (inches * 25.4).toFixed(2);
        });

        mmInput.addEventListener('input', function () {
            const mm = parseFloat(mmInput.value);
            inchesInput.value = isNaN(mm) ? '' : (mm / 25.4).toFixed(2);
        });
    };

    // Apply conversion to all bore and stroke fields
    syncInchesWithMM(document.getElementById('bore'), document.getElementById('bore-mm'));
    syncInchesWithMM(document.getElementById('stroke'), document.getElementById('stroke-mm'));
    syncInchesWithMM(document.getElementById('bore-stroke'), document.getElementById('bore-stroke-mm'));
    syncInchesWithMM(document.getElementById('stroke-bore'), document.getElementById('stroke-bore-mm'));

    // Function to sync CID and CC conversion
    const syncCIDWithCC = (cidInput, ccInput) => {
        cidInput.addEventListener('input', function () {
            const cid = parseFloat(cidInput.value);
            ccInput.value = isNaN(cid) ? '' : (cid * 16.387).toFixed(2); // 1 CID = 16.387 CC
        });

        ccInput.addEventListener('input', function () {
            const cc = parseFloat(ccInput.value);
            cidInput.value = isNaN(cc) ? '' : (cc / 16.387).toFixed(2);
        });
    };

    // Apply conversion to CID fields
    syncCIDWithCC(document.getElementById('cid'), document.getElementById('cid-cc'));
    syncCIDWithCC(document.getElementById('cid-bore'), document.getElementById('cid-bore-cc'));

    // Calculate CID
    document.querySelector('#cid-form').addEventListener('submit', function (event) {
        event.preventDefault();
        const bore = parseFloat(document.querySelector('#bore-mm').value);
        const stroke = parseFloat(document.querySelector('#stroke-mm').value);
        const cylinders = parseInt(document.querySelector('#cylinders').value, 10);

        if (isNaN(bore) || isNaN(stroke) || isNaN(cylinders) || cylinders <= 0) {
            document.querySelector('#cid-result').textContent = 'Invalid input';
            return;
        }

        const cid = 0.7854 * Math.pow(bore/25.4, 2) * stroke/25.4 * cylinders;
        const cid2liters = cid / 61.024;
        document.querySelector('#cid-result').textContent = cid.toFixed(2);
        document.querySelector('#liters-result').textContent = cid2liters.toFixed(1);
    });

    // Calculate Stroke
    document.querySelector('#stroke-form').addEventListener('submit', function (event) {
        event.preventDefault();
        const cid = parseFloat(document.querySelector('#cid').value);
        const bore = parseFloat(document.querySelector('#bore-stroke-mm').value);
        const cylinders = parseInt(document.querySelector('#cylinders-stroke').value, 10);

        if (isNaN(cid) || isNaN(bore) || isNaN(cylinders) || cylinders <= 0) {
            document.querySelector('#stroke-result').textContent = 'Invalid input';
            return;
        }

        const stroke = cid / (0.7854 * Math.pow(bore/25.4, 2) * cylinders);
        document.querySelector('#stroke-result').textContent = stroke.toFixed(3);
    });

    // Calculate Bore
    document.querySelector('#bore-form').addEventListener('submit', function (event) {
        event.preventDefault();
        const cid = parseFloat(document.querySelector('#cid-bore').value);
        const stroke = parseFloat(document.querySelector('#stroke-bore-mm').value);
        const cylinders = parseInt(document.querySelector('#cylinders-bore').value, 10);

        if (isNaN(cid) || isNaN(stroke) || isNaN(cylinders) || cylinders <= 0) {
            document.querySelector('#bore-result').textContent = 'Invalid input';
            return;
        }

        const bore = Math.sqrt(cid / (0.7854 * stroke/25.4 * cylinders));
        document.querySelector('#bore-result').textContent = bore.toFixed(2);
    });

});