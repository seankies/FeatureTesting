document.addEventListener('DOMContentLoaded', function () {
    // G-Force from HP, MPH, and Weight
    document.querySelector('#g-force-hp-mph-form').addEventListener('submit', function (event) {
        event.preventDefault();
        const hp = parseFloat(document.querySelector('#g-hp').value);
        const mph = parseFloat(document.querySelector('#g-mph').value);
        const weight = parseFloat(document.querySelector('#g-weight').value);
        
        if (isNaN(hp) || isNaN(mph) || isNaN(weight) || hp <= 0 || mph <= 0 || weight <= 0) {
            document.querySelector('#g-force-hp-mph-result').textContent = 'Invalid input';
            return;
        }

        const gForce = (hp * 375) / (weight * mph);
        document.querySelector('#g-force-hp-mph-result').textContent = `${gForce.toFixed(2)} G's`;
    });

    // G-Force from 60-Foot Time
    document.querySelector('#g-force-60ft-form').addEventListener('submit', function (event) {
        event.preventDefault();
        const sixtyFootTime = parseFloat(document.querySelector('#g-60ft').value);
        
        if (isNaN(sixtyFootTime) || sixtyFootTime <= 0) {
            document.querySelector('#g-force-60ft-result').textContent = 'Invalid input';
            return;
        }

        const gForce = 3.283 / (sixtyFootTime ** 2);
        document.querySelector('#g-force-60ft-result').textContent = `${gForce.toFixed(2)} G's`;
    });
});