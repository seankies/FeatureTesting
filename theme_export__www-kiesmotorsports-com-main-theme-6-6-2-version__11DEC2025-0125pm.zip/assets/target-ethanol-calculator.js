// Target Ethanol Calculator
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('target-ethanol-form');
    const outputAmount = document.getElementById('ethanol-output-amount');
    const outputFit = document.getElementById('ethanol-output-fit');

    // Synchronization function
    function syncInputs(percentageInput, decimalInput) {
        percentageInput.addEventListener('input', function () {
            const value = parseFloat(percentageInput.value);
            if (!isNaN(value)) {
                decimalInput.value = (value / 100).toFixed(2);
            } else {
                decimalInput.value = '';
            }
        });

        decimalInput.addEventListener('input', function () {
            const value = parseFloat(decimalInput.value);
            if (!isNaN(value)) {
                percentageInput.value = (value * 100);
            } else {
                percentageInput.value = '';
            }
        });
    }

    // Apply sync to all relevant input pairs
    syncInputs(document.getElementById('target-ethanol-percentage'), document.getElementById('target-ethanol-decimal'));
    syncInputs(document.getElementById('current-target-tank-percentage'), document.getElementById('current-target-tank-decimal'));
    syncInputs(document.getElementById('current-fuel-ethanol-percentage'), document.getElementById('current-fuel-ethanol-decimal'));
    syncInputs(document.getElementById('target-ethanol-added-percentage'), document.getElementById('target-ethanol-added-decimal'));

    form.addEventListener('submit', function (event) {
        event.preventDefault();

        // Retrieve input values
        const targetEthanol = parseFloat(document.getElementById('target-ethanol-decimal').value);
        const fuelCapacity = parseFloat(document.getElementById('fuel-tank-capacity').value);
        const currentTargetTankPercentage = parseFloat(document.getElementById('current-target-tank-decimal').value);
        const currentEthanol = parseFloat(document.getElementById('current-fuel-ethanol-decimal').value);
        const addedEthanol = parseFloat(document.getElementById('target-ethanol-added-decimal').value);

        // Validate inputs
        if (isNaN(targetEthanol) || isNaN(fuelCapacity) || isNaN(currentTargetTankPercentage) ||
            isNaN(currentEthanol) || isNaN(addedEthanol) ||
            targetEthanol < 0 || fuelCapacity <= 0 || currentTargetTankPercentage < 0 || 
            currentTargetTankPercentage > 1 || currentEthanol < 0 || currentEthanol > 1 || addedEthanol < 0 || addedEthanol > 1) {
            alert('Please enter valid values for all fields.');
            return;
        }

        // Calculate Gallons/Liters to target
        const ethanolNeeded = ((currentEthanol - targetEthanol) * currentTargetTankPercentage * fuelCapacity) / (targetEthanol - addedEthanol);

        // Calculate if mix fits in the tank
        const willFit = fuelCapacity < (ethanolNeeded + fuelCapacity * currentTargetTankPercentage) ? 'NO' : 'YES';

        // Display results
        outputAmount.textContent = ethanolNeeded.toFixed(2);
        outputFit.textContent = willFit;
    });
});