class ProductBundler {
  constructor() {
    this.bundler = document.querySelector('.bundler');
    if (!this.bundler) {
      console.error('Bundler not found');
      return;
    }

    this.selectedProducts = new Map();
    this.discountTiers = [];
    this.appliedDiscountTier = null;

    this.init();
  }

  init() {
    this.cacheDOMElements();
    this.loadDiscountTiers();
    this.setupEventListeners();
    this.updateUI();
  }

  cacheDOMElements() {
    this.productCards = document.querySelectorAll('.product-card');
    this.selectedItemsList = document.getElementById('selected-items-list');
    this.selectedCount = document.getElementById('selected-count');
    this.subtotalEl = document.getElementById('subtotal');
    this.discountAmountEl = document.getElementById('discount-amount');
    this.totalEl = document.getElementById('total');
    this.nextTierMessage = document.getElementById('next-tier-message');
    this.addToCartBtn = document.getElementById('add-to-cart-btn');
    this.discountRow = document.querySelector('.discount-row');
    this.discountTierElements = document.querySelectorAll('. discount-tier');
  }

  loadDiscountTiers() {
    this.discountTierElements.forEach(tier => {
      const minItems = parseInt(tier.dataset.minItems);
      const discount = parseInt(tier.dataset.discount);
      const type = tier.dataset.discountType;

      this.discountTiers.push({
        minItems,
        discount,
        type,
        element: tier
      });
    });

    this.discountTiers. sort((a, b) => a.minItems - b.minItems);
  }

  setupEventListeners() {
    this.productCards.forEach(card => {
      card.addEventListener('click', (e) => {
        e.preventDefault();
        this.selectProduct(card);
      });
    });

    this.discountTierElements.forEach(tier => {
      const btn = tier.querySelector('.tier-apply-btn');
      if (btn) {
        btn.addEventListener('click', (e) => {
          e.preventDefault();
          this.applyDiscount(tier);
        });
      }
    });

    if (this.addToCartBtn) {
      this.addToCartBtn.addEventListener('click', (e) => {
        e.preventDefault();
        this.addToCart();
      });
    }
  }

  selectProduct(card) {
    const productId = card.dataset.productId;
    const productTitle = card.dataset.productTitle;
    const productPrice = parseFloat(card.dataset.productPrice);
    const excludeDiscount = card.dataset.excludeDiscount === 'true';

    if (this.selectedProducts.has(productId)) {
      this.selectedProducts.delete(productId);
      card.classList.remove('selected');
    } else {
      this. selectedProducts.set(productId, {
        id: productId,
        title:  productTitle,
        price: productPrice,
        excludeDiscount:  excludeDiscount
      });
      card.classList.add('selected');
    }

    this.updateUI();
  }

  updateUI() {
    this.renderSelectedItems();
    this.calculatePricing();
    this.updateDiscountTiers();
    this.updateNextTierMessage();

    if (this.addToCartBtn) {
      this.addToCartBtn.disabled = this. selectedProducts.size === 0;
    }
  }

  renderSelectedItems() {
    const count = this.selectedProducts.size;
    this.selectedCount.textContent = count;

    if (count === 0) {
      this.selectedItemsList.innerHTML = '<p class="empty-message">Select products to build your bundle</p>';
      return;
    }

    let html = '';
    this.selectedProducts.forEach((product, id) => {
      const price = (product.price / 100).toFixed(2);
      html += `
        <div class="selected-item" data-id="${id}">
          <span class="selected-item-name">${product. title}</span>
          <span class="selected-item-price">$${price}</span>
          <button class="remove-item-btn" type="button">×</button>
        </div>
      `;
    });

    this.selectedItemsList.innerHTML = html;

    document.querySelectorAll('.remove-item-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const item = btn.closest('.selected-item');
        const id = item.dataset.id;
        const card = document.querySelector(`[data-product-id="${id}"]`);
        this.selectProduct(card);
      });
    });
  }

  calculatePricing() {
    let subtotal = 0;

    this.selectedProducts.forEach(product => {
      subtotal += product.price / 100;
    });

    let discount = 0;

    if (this.appliedDiscountTier) {
      const tier = this.appliedDiscountTier;
      const discountableProducts = Array.from(this.selectedProducts. values()).filter(p => ! p.excludeDiscount);
      const discountableAmount = discountableProducts.reduce((sum, p) => sum + (p.price / 100), 0);

      if (tier.type === 'percent') {
        discount = (discountableAmount * tier.discount) / 100;
      } else {
        discount = tier.discount;
      }
    }

    const total = subtotal - discount;

    this.subtotalEl.textContent = `$${subtotal.toFixed(2)}`;
    this.totalEl.textContent = `$${total.toFixed(2)}`;

    if (discount > 0) {
      this.discountAmountEl.textContent = `-$${discount.toFixed(2)}`;
      this.discountRow.style.display = 'flex';
    } else {
      this.discountRow.style.display = 'none';
    }
  }

  updateDiscountTiers() {
    const count = this.selectedProducts.size;

    this.discountTierElements.forEach(tier => {
      const minItems = parseInt(tier. dataset.minItems);
      if (count >= minItems) {
        tier.classList.add('unlocked');
      } else {
        tier.classList.remove('unlocked');
      }
    });
  }

  updateNextTierMessage() {
    const count = this.selectedProducts.size;
    const nextTier = this.discountTiers.find(t => t. minItems > count);

    if (count === 0) {
      const firstTier = this.discountTiers[0];
      this. nextTierMessage.textContent = firstTier 
        ? `Add ${firstTier.minItems} items to get ${firstTier.discount}${firstTier.type === 'percent' ? '%' : '$'} off`
        : 'Add products to see discounts';
    } else if (nextTier) {
      const needed = nextTier.minItems - count;
      const text = needed === 1 ? 'item' : 'items';
      this.nextTierMessage.textContent = `Add ${needed} more ${text} to get ${nextTier.discount}${nextTier.type === 'percent' ?  '%' : '$'} off`;
    } else {
      this.nextTierMessage.textContent = '🎉 Best deal unlocked!';
    }
  }

  applyDiscount(tierElement) {
    const minItems = parseInt(tierElement.dataset. minItems);

    if (this.selectedProducts.size < minItems) {
      alert(`Need ${minItems} items for this discount`);
      return;
    }

    const tier = this.discountTiers.find(t => t.minItems === minItems);
    this.appliedDiscountTier = tier;
    this.updateUI();
  }

  addToCart() {
    if (this.selectedProducts.size === 0) {
      alert('Please select at least one product');
      return;
    }

    this.addToCartBtn.disabled = true;
    this.addToCartBtn.textContent = 'Adding...';

    const items = Array.from(this.selectedProducts.values()).map(p => ({
      id: p.id,
      quantity: 1,
      properties: {
        'Bundle Item': 'Yes',
        'Discount Applied': this.appliedDiscountTier ?  `${this.appliedDiscountTier.discount}${this.appliedDiscountTier.type === 'percent' ?  '%' : '$'}` : 'None'
      }
    }));

    fetch('/cart/add. js', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items })
    })
    .then(r => r.json())
    .then(() => {
      this.addToCartBtn.textContent = '✓ Added! ';
      setTimeout(() => window.location.href = '/cart', 500);
    })
    .catch(err => {
      console.error(err);
      this.addToCartBtn.disabled = false;
      this.addToCartBtn.textContent = 'Add to Cart';
      alert('Error adding to cart');
    });
  }
}

document.addEventListener('DOMContentLoaded', () => new ProductBundler());