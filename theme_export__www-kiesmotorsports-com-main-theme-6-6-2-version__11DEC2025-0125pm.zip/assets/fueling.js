// Fueling Calculator
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('fueling-form');
    const resultsTable = document.getElementById('results-table');
    const rowLbs = document.getElementById('row-lbs');
    const rowCc = document.getElementById('row-cc');

    const fuelTypes = [
        { type: 'Non-ethanol gasoline (E0)', afr: 14.7 },
        { type: 'Pump gasoline (E10)', afr: 14.1 },
        { type: 'E30', afr: 12.99 },
        { type: 'E40', afr: 12.42 },
        { type: 'E60', afr: 11.28 },
        { type: 'E85', afr: 9.8 },
        { type: 'E90', afr: 9.5 },
        { type: 'E98', afr: 9.0 },
        { type: 'Methanol', afr: 6.4 }
    ];

    form.addEventListener('submit', function (event) {
        event.preventDefault();

        // Input values
        const numInjectors = parseFloat(document.getElementById('number-injectors').value);
        const targetHP = parseFloat(document.getElementById('target-horsepower').value);
        const bsfc_fueling = parseFloat(document.getElementById('bsfc-fueling').value);
        const dutyCycle = parseFloat(document.getElementById('injector-duty-cycle').value);

        // Validate inputs
        if (isNaN(numInjectors) || isNaN(targetHP) || isNaN(bsfc_fueling) || isNaN(dutyCycle) || numInjectors <= 0 || targetHP <= 0 || bsfc_fueling <= 0 || dutyCycle <= 0 || dutyCycle > 1) {
            alert('Please enter valid input values.');
            return;
        }

        // Base fuel flow calculation (lbs/hr)
        const baseFuelFlowLbs = ((targetHP * bsfc_fueling) / (numInjectors * dutyCycle));

        // Base fuel flow (cc/min)
        const baseFuelFlowCc = baseFuelFlowLbs * 10.5;

        // Clear previous results
        rowLbs.innerHTML = '<th>Fuel flow needed per injector (lbs/hr)</th>';
        rowCc.innerHTML = '<th>Fuel flow needed per injector (cc/min)</th>';

        // Add base fuel flow (unchanged)
        rowLbs.insertAdjacentHTML('beforeend', `<td>${baseFuelFlowLbs.toFixed(2)}</td>`);
        rowCc.insertAdjacentHTML('beforeend', `<td>${baseFuelFlowCc.toFixed(2)}</td>`);

        // Generate table cells for adjusted values based on AFR
        fuelTypes.forEach(fuel => {
            if (fuel.afr != 14.7) {  // Skip adjusting base fuel flow for E0 (AFR 14.7)
                // Adjusted Fuel Flow based on AFR
                const adjustedFuelFlowLbs = baseFuelFlowLbs * (14.7/fuel.afr);
                const adjustedFuelFlowCc = adjustedFuelFlowLbs * 10.5;

                // Add adjusted values for other fuel types
                rowLbs.insertAdjacentHTML('beforeend', `<td>${adjustedFuelFlowLbs.toFixed(2)}</td>`);
                rowCc.insertAdjacentHTML('beforeend', `<td>${adjustedFuelFlowCc.toFixed(2)}</td>`);
            }
        });

        // Show results table
        resultsTable.style.display = 'block';
    });
});