const BASE_URL = '/search?q=*&type=product&view=DO-NOT-USE';

async function fetchDataAndPopulateDropdowns(selectedDropdown = null) {
    try {
        const url = constructUrl();
        const response = await fetch(url);
        const data = await response.json();
        console.clear();
        console.log(url, data);
        if (!selectedDropdown) {
            const dropdowns = document.querySelectorAll('.ymm-dropdown');
            data.results.forEach((filter, index) => {
                dropdowns[index].setAttribute('data-param', filter.param_name);
                populateDropdown(dropdowns[index], filter.values,filter.label);
            });
        } else {
            const subsequentDropdowns = getNextDropdownSiblings(selectedDropdown);
            subsequentDropdowns.forEach(dropdown => {
                if (dropdown.tagName === "SELECT") {
                    const dropdownIndex = Array.from(document.querySelectorAll('.ymm-dropdown')).indexOf(dropdown);
                    if (data.results[dropdownIndex]) {
                        populateDropdown(dropdown, data.results[dropdownIndex].values,data.results[dropdownIndex].label);
                        dropdown.selectedIndex = 0;
                    }
                }
            });
        }
    } catch (error) {
        console.error('Error fetching data:', error);
    }
}

function constructUrl(removeTemplate = false ) {
    let url = (removeTemplate == true) ? BASE_URL.toString().replace("&view=DO-NOT-USE",'') : BASE_URL;
    document.querySelectorAll('.ymm-dropdown').forEach(dropdown => {
        const value = dropdown.value;
        if (value !== "0" && value != null) {
            const key = dropdown.getAttribute('data-param');
            url += `&${key}=${value.replace(/\s+/g, '+')}`;
        }
    });
    return url;
}

function populateDropdown(dropdown, values,label) {
    dropdown.innerHTML = `<option value="0">Select ${label}</option>`;
    values.forEach(value => {
        if (value.count > 0) {
            const option = document.createElement('option');
            option.value = value.value.replace(/\s+/g, '+');
            option.textContent = `${value.label} (${value.count})`; // Display count next to label
            dropdown.appendChild(option);
        }
    });
    dropdown.disabled = false;
}
function getNextDropdownSiblings(element) {
    let sibling = element.nextElementSibling;
    const siblings = [];
    while (sibling) {
        if (sibling.tagName === "SELECT" && sibling.classList.contains('ymm-dropdown')) {
            siblings.push(sibling);
        }
        sibling = sibling.nextElementSibling;
    }
    return siblings;
}


document.getElementById('data-search').addEventListener('change', function(event) {
    if (event.target.classList.contains('ymm-dropdown')) {
        const selectedDropdown = event.target;
        fetchDataAndPopulateDropdowns(selectedDropdown);
    }
});

document.querySelector('.ymm-search').addEventListener('click', function() {
    const selectedValues = {};
    document.querySelectorAll('.ymm-dropdown').forEach(dropdown => {
        if (dropdown.value) {
            selectedValues[dropdown.getAttribute('data-param')] = dropdown.value;
        }
    });
    const url = constructUrl(true);
    //console.log(url);
    window.location.href = url;
});

// Call the function to populate the dropdowns on page load
window.addEventListener('DOMContentLoaded', (event) => {
    fetchDataAndPopulateDropdowns();
});
