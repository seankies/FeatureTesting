// Ethanol Calculator
document.addEventListener('DOMContentLoaded', function () {
    const syncPercentageWithDecimal = (percentageInput, decimalInput) => {
        percentageInput.addEventListener('input', function () {
            const value = parseFloat(percentageInput.value);
            decimalInput.value = isNaN(value) ? '' : (value / 100).toFixed(2);
        });

        decimalInput.addEventListener('input', function () {
            const value = parseFloat(decimalInput.value);
            percentageInput.value = isNaN(value) ? '' : (value * 100);
        });
    };

    // Synchronize Current Tank % inputs
    syncPercentageWithDecimal(
        document.getElementById('current-tank-percentage'),
        document.getElementById('current-tank-decimal')
    );

    // Synchronize Current Ethanol % inputs
    syncPercentageWithDecimal(
        document.getElementById('current-ethanol-percentage'),
        document.getElementById('current-ethanol-decimal')
    );

    // Synchronize Ethanol Added % inputs
    syncPercentageWithDecimal(
        document.getElementById('ethanol-added-percentage'),
        document.getElementById('ethanol-added-decimal')
    );
});
    
document.addEventListener('DOMContentLoaded', function () {
    const litersInput = document.getElementById('fuel-capacity-liters');
    const gallonsInput = document.getElementById('fuel-capacity-gallons');
    const ethanolAddedPercentageInput = document.getElementById('ethanol-added-percentage');
    const ethanolAddedDecimalInput = document.getElementById('ethanol-added-decimal');
    const litersToGallons = 0.264172; // 1 liter = 0.264172 gallons

    // Synchronize liters and gallons
    if (litersInput && gallonsInput) {
        litersInput.addEventListener('input', function () {
            const liters = parseFloat(litersInput.value);
            if (!isNaN(liters)) {
                gallonsInput.value = (liters * litersToGallons).toFixed(6);
            } else {
                gallonsInput.value = '';
            }
        });

        gallonsInput.addEventListener('input', function () {
            const gallons = parseFloat(gallonsInput.value);
            if (!isNaN(gallons)) {
                litersInput.value = (gallons / litersToGallons).toFixed(6);
            } else {
                litersInput.value = '';
            }
        });
    }

    // Update ethanol calculator logic
    const form = document.getElementById('ethanol-form');
    const resultValue = document.getElementById('ethanol-result-value');

    form.addEventListener('submit', function (event) {
        event.preventDefault();

        const fuelCapacity = parseFloat(litersInput.value);
        const currentTankPercentage = parseFloat(document.getElementById('current-tank-percentage').value);
        const currentEthanolPercentage = parseFloat(document.getElementById('current-ethanol-percentage').value / 100);
        const ethanolAddedPercentage = parseFloat(ethanolAddedDecimalInput.value || ethanolAddedPercentageInput.value / 100);

        // Validation
        if (
            isNaN(fuelCapacity) || isNaN(currentTankPercentage) ||
            isNaN(currentEthanolPercentage) || isNaN(ethanolAddedPercentage) ||
            fuelCapacity <= 0 || currentTankPercentage < 0 || currentTankPercentage > 100 ||
            currentEthanolPercentage < 0 || currentEthanolPercentage > 1 ||
            ethanolAddedPercentage < 0 || ethanolAddedPercentage > 1
        ) {
            resultValue.textContent = 'Invalid input';
            return;
        }

        // Formula calculation
        const maxEthanolPercentage = (
            (
                (fuelCapacity * (currentTankPercentage / 100) * currentEthanolPercentage) +
                (fuelCapacity * ((100 - currentTankPercentage) / 100) * ethanolAddedPercentage)
            ) / fuelCapacity
        ) * 100;

        // Output result
        resultValue.textContent = maxEthanolPercentage.toFixed(2);
    });
});