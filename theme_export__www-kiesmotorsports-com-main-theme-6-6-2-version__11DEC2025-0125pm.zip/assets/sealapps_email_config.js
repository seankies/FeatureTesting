/**
 * 当前配置所属：正式服
 * 本文件为c端脚本配置文件，非必要情况下不做修改，若有必须修改请务必确认当前文件为正式服还是测试服的配置
 */
const apiBaseUrl = 'https://emailnoticeapi.sealapps.com/';
const isDebug = false;