// Fuel Injector Calculator
document.addEventListener('DOMContentLoaded', function () {
    const syncPercentageWithDecimal = (percentageInput, decimalInput) => {
        percentageInput.addEventListener('input', function () {
            const value = parseFloat(percentageInput.value);
            decimalInput.value = isNaN(value) ? '' : (value / 100).toFixed(2);
        });

        decimalInput.addEventListener('input', function () {
            const value = parseFloat(decimalInput.value);
            percentageInput.value = isNaN(value) ? '' : (value * 100).toFixed(0);
        });
    };

    // Synchronize Maximum Injector Duty Cycle inputs (Decimal and Percentage)
    syncPercentageWithDecimal(
        document.getElementById('max-duty-cycle-percent'),
        document.getElementById('max-duty-cycle')
    );

    const form = document.getElementById('fuel-form');
    
    form.addEventListener('submit', function (event) {
        event.preventDefault();

        const numInjectors = parseFloat(document.getElementById('num-injectors').value);
        const injectorFlowRate = parseFloat(document.getElementById('injector-flow-rate').value);
        const maxDutyCycle = parseFloat(document.getElementById('max-duty-cycle').value);
        const targetFuelPressure = parseFloat(document.getElementById('target-fuel-pressure').value);
        const maxBoostPressure = parseFloat(document.getElementById('max-boost-pressure').value);

        // Validation
        if (
            isNaN(numInjectors) || isNaN(injectorFlowRate) || isNaN(maxDutyCycle) || 
            isNaN(targetFuelPressure) || isNaN(maxBoostPressure) ||
            numInjectors <= 0 || injectorFlowRate <= 0 || maxDutyCycle <= 0 || maxDutyCycle > 1 ||
            targetFuelPressure <= 0 || maxBoostPressure < 0
        ) {
            alert('Invalid input! Please enter valid values.');
            return;
        }

        // Fuel Flow per Injector (cc/min)
        const fuelFlowInjector = injectorFlowRate * maxDutyCycle * (targetFuelPressure / 43.5);

        // Fuel Flow in LPH (vacuum reference/return style)
        const fuelFlowLphBoosted = (((fuelFlowInjector * numInjectors) * 0.06) * 1.1);
        const fuelPressureBoosted = targetFuelPressure + maxBoostPressure;

        // Fuel Flow in LPH (non vacuum referenced/returnless)
        const fuelFlowLphNonVacuum = (((fuelFlowInjector * numInjectors) * 0.06) * 1.36);
        const fuelPressureNonVacuum = targetFuelPressure;

        // Display results
        document.getElementById('fuel-flow-injector').textContent = fuelFlowInjector.toFixed(2);
        document.getElementById('fuel-flow-lph-boosted').textContent = fuelFlowLphBoosted.toFixed(2);
        document.getElementById('fuel-pressure-boosted').textContent = fuelPressureBoosted.toFixed(2);
        document.getElementById('fuel-flow-lph-non-vacuum').textContent = fuelFlowLphNonVacuum.toFixed(2);
        document.getElementById('fuel-pressure-non-vacuum').textContent = fuelPressureNonVacuum.toFixed(2);
    });
});