
class QuantityInputBundle extends HTMLElement {
    constructor() {
        super();
        this.parent = this.parentElement.parentElement.parentElement;
        this.input = this.querySelector('.variant_quantity_option');
        this.changeEvent = new Event('change', { bubbles: true });
        this.input.addEventListener('change', this.onInputChangeBundle.bind(this));

        this.querySelectorAll('.button_bundle').forEach(
            (button) => button.addEventListener('click', this.onButtonClickBundle.bind(this))
        );

        // if (!this.checkHasMultipleVariantsBundle()) {
        //     this.initProductQuantityBundle();
        //     this.checkVariantInventoryBundle();
        // }
    }

    onInputChangeBundle(event) {
        event.preventDefault(); 
        var inputValue = this.input.value;
        var maxValue = parseInt(this.input.dataset.inventoryQuantity);
        var currentId = document.getElementById(`product-form-${this.input.dataset.product}`)?.querySelector('[name="id"]')?.value;
        // var saleOutStock  = document.getElementById('product-add-to-cart').dataset.available === 'true' || false ;
        const addButtonBundle = document.getElementById(`product-form-${this.input.dataset.product}`)?.querySelector('[name="add"]');

        if(this.input.classList.contains('variant_quantity_option')) {

            var quantity_checkbox = document.querySelector(`.${this.parent.className} .bundle_check .checkbox_option_bundle-${this.input.dataset.orderId}`)
            let currency =  localStorage.getItem("currency") ;
            var quantityValue = document.querySelector(`.${this.parent.className} .checkbox_option_bundle_${this.input.dataset.orderId}_quantity`).value;
            var bundleItemPricePrev = document.querySelector(`.${this.parent.className} .preview_price-${this.input.dataset.orderId} .money`);
            var bundleItemPrice = document.querySelector(`.${this.parent.className} .preview_price-${this.input.dataset.orderId}`);
            let priceQ = this.input.getAttribute("data-variant-price");

            quantity_checkbox.dataset.variantQuantity = quantityValue;

            inputValue = parseInt(inputValue )
            priceQ = parseFloat(priceQ.replace(/,/g, '').replace(/[^0-9.]/g, ''));

            var newPrice = inputValue * priceQ;

            
            if(bundleItemPricePrev) {
                bundleItemPricePrev.textContent = `${currency}${newPrice.toFixed(2)}`;
            }
            if(bundleItemPrice){
                bundleItemPrice.textContent = `${currency}${newPrice.toFixed(2)}`;
            }
            quantity_checkbox.dataset.productPrice  = `${currency}${newPrice.toFixed(2)}`;
            
        }

        if(inputValue < 1) {
            inputValue = 1;
            this.input.value =  inputValue;
        }
        
        if (inputValue > maxValue && !saleOutStock && maxValue > 0) {
            var arrayInVarName = `selling_array_${this.input.dataset.product}`,
                itemInArray = window[arrayInVarName],
                itemStatus = itemInArray[currentId];
          
            if(itemStatus == 'deny') {
                inputValue = maxValue
                this.input.value = inputValue;
                const message = getInputMessage(maxValue)
                showWarning(message, 3000)
            }

        } else if (inputValue > maxValue && saleOutStock && maxValue <= 0) {
            this.input.value = inputValue;
        }

        if(window.subtotal.show) {
            var text,
                price = this.input.dataset.price,
                subTotal = 0;

            var parser = new DOMParser();

            subTotal = inputValue * price;
            subTotal = Shopify.formatMoney(subTotal, window.money_format);
            subTotal = extractContent(subTotal);

            const moneySpan = document.createElement('span')
            moneySpan.classList.add(window.currencyFormatted ? 'money' : 'money-subtotals') 
            moneySpan.innerText = subTotal 
            document.body.appendChild(moneySpan) 

            if (this.checkNeedToConvertCurrency()) {
                let currencyCode = document.getElementById('currencies')?.querySelector('.active')?.getAttribute('data-currency');
                Currency.convertAll(window.shop_currency, currencyCode, 'span.money', 'money_format');
            }

            subTotal = moneySpan.innerText 
            $(moneySpan).remove()

            if (window.subtotal.style == '1') {
                const pdView_subTotal = document.querySelector('.productView-subtotal .money') || document.querySelector('.productView-subtotal .money-subtotal');

                pdView_subTotal.textContent = subTotal;
            }
            else if (window.subtotal.style == '2') {
                text = window.subtotal.text.replace('[value]', subTotal);

                addButtonBundle.textContent = text;  
            }

            const stickyPrice = $('[data-sticky-add-to-cart] .money-subtotals .money');
            const stickyComparePrice = $('[data-sticky-add-to-cart] .money-compare-price .money');

            if (stickyPrice.length) {
                stickyPrice.text(subTotal);
            }

            if (stickyComparePrice.length && window.subtotal.show) {

                let comparePrice = $('[data-sticky-add-to-cart] .money-compare-price').data('compare-price');
                comparePrice = inputValue * comparePrice;
                comparePrice = Shopify.formatMoney(comparePrice, window.money_format);
                comparePrice = extractContent(comparePrice);
                stickyComparePrice.text(comparePrice);

            }
        }

        if (this.classList.contains('quantity__group--2') || this.classList.contains('quantity__group--3')) {
            const mainQty = document.querySelector('.quantity__group--1 .quantity__input');
            mainQty.value = inputValue;

            const mainQty2Exists = !!document.querySelector('.quantity__group--2 .quantity__input');
            const mainQty3Exists = !!document.querySelector('.quantity__group--3 .quantity__input');

            if (this.classList.contains('quantity__group--2') && mainQty3Exists) {
                const mainQty3 = document.querySelector('.quantity__group--3 .quantity__input');
                mainQty3.value = inputValue;
            }
            else if (this.classList.contains('quantity__group--3') && mainQty2Exists) {
                const mainQty2 = document.querySelector('.quantity__group--2 .quantity__input');
                mainQty2.value = inputValue;
            }
        }
    }

    onButtonClickBundle(event) {
        event.preventDefault();
        const previousValue = this.input.value;
        var inputValue = this.input.value;

        event.target.name === 'plus' ? this.input.stepUp() : this.input.stepDown();
        if (previousValue !== this.input.value) this.input.dispatchEvent(this.changeEvent);

        if(event.target.name === 'plus') {

            var checkboxData = document.querySelector(`.${this.parent.className} .bundle_check .checkbox_option_bundle-${this.input.dataset.orderId}`);

            if( checkboxData.checked ) {

                let currency =  localStorage.getItem("currency") ;
                var checkboxState = localStorage.getItem('subtotal_price');
                let basePrice = parseFloat(checkboxState);
                let priceQ = this.input.getAttribute("data-variant-price")
    
                priceQ = priceQ.replace(/[^0-9.]/g, '');
                priceQ = parseFloat(priceQ)
                let currentPrice = basePrice + priceQ;
    
                localStorage.setItem('subtotal_price',currentPrice.toFixed(2));
    
                var priceValue = document.querySelector('#byk_sub_total_price')
                if( priceValue ) {
                    priceValue.textContent = `${currency}${localStorage.getItem('subtotal_price')}`;
                }
            }

        } else {
      
            var checkboxData = document.querySelector(`.${this.parent.className} .bundle_check .checkbox_option_bundle-${this.input.dataset.orderId}`);


            if(checkboxData.checked){
                let currency =  localStorage.getItem("currency") ;
                var checkboxState = localStorage.getItem('subtotal_price');
                let basePrice = parseFloat(checkboxState);
                let priceQ = this.input.getAttribute("data-variant-price")
                priceQ = priceQ.replace(/[^0-9.]/g, '');
                priceQ = parseFloat(priceQ)

                if(inputValue > 1){
                    var currentPrice = basePrice - priceQ;
                }
            
                localStorage.setItem('subtotal_price',currentPrice.toFixed(2));
    
                var priceValue = document.querySelector('#byk_sub_total_price')
                if(priceValue) {
                    priceValue.textContent = `${currency}${localStorage.getItem('subtotal_price')}`;
                }
            }
        }
    }

    checkNeedToConvertCurrency() {
        return (window.show_multiple_currencies && Currency.currentCurrency != shopCurrency) || window.show_auto_currency;
    }
    
    // checkHasMultipleVariantsBundle() {
    //     const arrayInVarName = `product_inven_array_${this.querySelector('[data-product]').dataset.product}`
    //     this.inven_array = window[arrayInVarName];
    //     return Object.keys(this.inven_array).length > 1
    // }
        
    initProductQuantityBundle() {
        if(this.inven_array != undefined) {
            var inven_num = Object.values(this.inven_array),
                inventoryQuantity = parseInt(inven_num);
            this.querySelector('input[name="quantity"]').setAttribute('data-inventory-quantity', inventoryQuantity);
            this.querySelector('input[name="quantity"]').dataset.inventoryQuantity = inventoryQuantity
        }
    }

    checkVariantInventoryBundle() {
        const addBtn = document.getElementById('product-add-to-cart')
        this.input.disabled = addBtn.disabled 
        this.querySelector('.btn-quantity.minus').disabled = addBtn.disabled
        this.querySelector('.btn-quantity.plus').disabled = addBtn.disabled
    }

    getVariantData() {
        this.variantData = this.variantData || JSON.parse(document.querySelector('.product-option [type="application/json"]').textContent);
        return this.variantData;
    }
}

customElements.define('quantity-bundle', QuantityInputBundle);
