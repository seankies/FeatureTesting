document.addEventListener('DOMContentLoaded', function () {
    // HP from ET and Weight
    document.querySelector('#hp-from-et-form').addEventListener('submit', function (event) {
        event.preventDefault();
        const et = parseFloat(document.querySelector('#et').value);
        const weight = parseFloat(document.querySelector('#weight-et').value);
        
        if (isNaN(et) || isNaN(weight) || et <= 0 || weight <= 0) {
            document.querySelector('#hp-from-et-result').textContent = 'Invalid input';
            return;
        }

        const hp = weight / ((et / 5.825) ** 3);
        document.querySelector('#hp-from-et-result').textContent = hp.toFixed(2);
    });

    // HP from MPH and Weight
    document.querySelector('#hp-from-mph-form').addEventListener('submit', function (event) {
        event.preventDefault();
        const mph = parseFloat(document.querySelector('#mph').value);
        const weight = parseFloat(document.querySelector('#weight-mph').value);
        
        if (isNaN(mph) || isNaN(weight) || mph <= 0 || weight <= 0) {
            document.querySelector('#hp-from-mph-result').textContent = 'Invalid input';
            return;
        }

        const hp = (weight * (mph / 235) ** 3);
        document.querySelector('#hp-from-mph-result').textContent = hp.toFixed(2);
    });

    // ET and MPH from HP and Weight
    document.querySelector('#et-mph-from-hp-form').addEventListener('submit', function (event) {
        event.preventDefault();
        const hp = parseFloat(document.querySelector('#hp-input').value);
        const weight = parseFloat(document.querySelector('#weight-hp').value);
        
        if (isNaN(hp) || isNaN(weight) || hp <= 0 || weight <= 0) {
            document.querySelector('#et-result').textContent = 'Invalid input';
            document.querySelector('#mph-result').textContent = 'Invalid input';
            return;
        }

        const et = 5.825 * ((weight / hp) ** (1/3));
        const mph = 232 * ((hp / weight) ** (1/3));
        
        document.querySelector('#et-result').textContent = et.toFixed(2);
        document.querySelector('#mph-result').textContent = mph.toFixed(2);
    });
});