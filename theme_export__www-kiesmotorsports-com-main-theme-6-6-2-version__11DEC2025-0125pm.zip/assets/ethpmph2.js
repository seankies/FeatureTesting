document.addEventListener('DOMContentLoaded', function () {
    // HP from ET and Weight
    document.querySelector('#hp-from-et-form-2').addEventListener('submit', function (event) {
        event.preventDefault();
        const et = parseFloat(document.querySelector('#et-2').value);
        const weight = parseFloat(document.querySelector('#weight-et-2').value);
        
        if (isNaN(et) || isNaN(weight) || et <= 0 || weight <= 0) {
            document.querySelector('#hp-from-et-result-2').textContent = 'Invalid input';
            return;
        }

        const hp = weight / ((et / 3.669) ** 3);
        document.querySelector('#hp-from-et-result-2').textContent = hp.toFixed(0);
    });

    // HP from MPH and Weight
    document.querySelector('#hp-from-mph-form-2').addEventListener('submit', function (event) {
        event.preventDefault();
        const mph = parseFloat(document.querySelector('#mph-2').value);
        const weight = parseFloat(document.querySelector('#weight-mph-2').value);
        
        if (isNaN(mph) || isNaN(weight) || mph <= 0 || weight <= 0) {
            document.querySelector('#hp-from-mph-result-2').textContent = 'Invalid input';
            return;
        }

        const hp = (weight * (mph / 186.01) ** 3);
        document.querySelector('#hp-from-mph-result-2').textContent = hp.toFixed(0);
    });

    // ET and MPH from HP and Weight
    document.querySelector('#et-mph-from-hp-form-2').addEventListener('submit', function (event) {
        event.preventDefault();
        const hp = parseFloat(document.querySelector('#hp-input-2').value);
        const weight = parseFloat(document.querySelector('#weight-hp-2').value);
        
        if (isNaN(hp) || isNaN(weight) || hp <= 0 || weight <= 0) {
            document.querySelector('#et-result-2').textContent = 'Invalid input';
            document.querySelector('#mph-result-2').textContent = 'Invalid input';
            return;
        }

        const et = 3.669 * ((weight / hp) ** (1/3));
        const mph = 186.01 * ((hp / weight) ** (1/3));
        
        document.querySelector('#et-result-2').textContent = et.toFixed(2);
        document.querySelector('#mph-result-2').textContent = mph.toFixed(2);
    });
});