(function () {
  const ACCORDION_SELECTOR = 'details[data-accordion="true"]';

  function closeOthersInGroup(openDetails) {
    const group = openDetails.getAttribute('data-accordion-group');
    if (!group) return;

    document.querySelectorAll(ACCORDION_SELECTOR + '[data-accordion-group="' + CSS.escape(group) + '"]')
      .forEach(el => {
        if (el !== openDetails && el.hasAttribute('open')) {
          el.removeAttribute('open');
        }
      });
  }

  function onToggle(e) {
    const el = e.target;
    if (el.matches(ACCORDION_SELECTOR) && el.open) {
      closeOthersInGroup(el);
    }
  }

  // Initial + dynamic binding
  document.addEventListener('toggle', onToggle, true);

  // Handle Theme Editor section reloads
  document.addEventListener('shopify:section:load', function (e) {
    // No extra wiring needed; the 'toggle' listener is global.
    // But you could auto-close duplicates that start open:
    const root = e.target;
    root.querySelectorAll(ACCORDION_SELECTOR + '[open]').forEach(closeOthersInGroup);
  });
})();