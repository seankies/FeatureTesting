// Turbo Compressor Sizing
document.addEventListener('DOMContentLoaded', function () {
    const airflowForm = document.querySelector('#airflow-form');
    const airflowResult = document.querySelector('#airflow-result-value');

    if (airflowForm && airflowResult) {
        airflowForm.addEventListener('submit', function (event) {
            event.preventDefault();

            const targetHP = parseFloat(document.querySelector('#target-hp').value);
            const airFuelRatio = parseFloat(document.querySelector('#air-fuel-ratio').value);
            const bsfc = parseFloat(document.querySelector('#bsfc').value);

            if (isNaN(targetHP) || isNaN(airFuelRatio) || isNaN(bsfc)) {
                airflowResult.textContent = 'Invalid input';
                return;
            }

            const airflow = targetHP * airFuelRatio * (bsfc / 60);

            airflowResult.textContent = airflow.toFixed(2);
        });
    }

    const pressureForm = document.querySelector('#pressure-form');
    const absolutePressureResult = document.querySelector('#absolute-pressure-result');
    const boostPressureResult = document.querySelector('#boost-pressure-result');
    const pressureRatioResult = document.querySelector('#pressure-ratio-result');

    if (pressureForm) {
        pressureForm.addEventListener('submit', function (event) {
            event.preventDefault();

            const airflowTargetHP = parseFloat(document.querySelector('#airflow-target-hp').value);
            const intakeTemp = parseFloat(document.querySelector('#intake-temp').value);
            const volumetricEfficiency = parseFloat(document.querySelector('#volumetric-efficiency').value);
            const maxRPM = parseFloat(document.querySelector('#max-rpm').value);
            const engineDisplacement = parseFloat(document.querySelector('#engine-displacement').value);
            const ambientPressure = parseFloat(document.querySelector('#ambient-pressure').value);
            const airFilter = parseFloat(document.querySelector('#air-filter').value);
            const intercooler = parseFloat(document.querySelector('#intercooler').value);

            if (
                isNaN(airflowTargetHP) || isNaN(intakeTemp) || isNaN(volumetricEfficiency) ||
                isNaN(maxRPM) || isNaN(ambientPressure) || isNaN(airFilter) || isNaN(intercooler) ||
                isNaN(engineDisplacement) || engineDisplacement <= 0
            ) {
                absolutePressureResult.textContent = 'Invalid input';
                boostPressureResult.textContent = 'Invalid input';
                pressureRatioResult.textContent = 'Invalid input';
                return;
            }

            const absolutePressure = (airflowTargetHP * 639.6 * (460 + intakeTemp)) / (volumetricEfficiency * (maxRPM / 2) * engineDisplacement);
            const targetBoostPressure = absolutePressure - ambientPressure;
            const pressureRatio = (targetBoostPressure + intercooler) / (ambientPressure - airFilter);

            absolutePressureResult.textContent = absolutePressure.toFixed(8);
            boostPressureResult.textContent = targetBoostPressure.toFixed(8);
            pressureRatioResult.textContent = pressureRatio.toFixed(9);
        });
    }
});    

// Engine Displacement Conversion
document.addEventListener('DOMContentLoaded', function () {
    const cubicInchesInput = document.querySelector('#engine-displacement');
    const litersInput = document.querySelector('#engine-displacement-liters');

    if (cubicInchesInput && litersInput) {
        const litersToCubicInches = 61.023744;

        litersInput.addEventListener('input', function () {
            const liters = parseFloat(litersInput.value);
            if (!isNaN(liters)) {
                cubicInchesInput.value = (liters * litersToCubicInches).toFixed(3);
            } else {
                cubicInchesInput.value = '';
            }
        });

        cubicInchesInput.addEventListener('input', function () {
            const cubicInches = parseFloat(cubicInchesInput.value);
            if (!isNaN(cubicInches)) {
                litersInput.value = (cubicInches / litersToCubicInches).toFixed(3);
            } else {
                litersInput.value = '';
            }
        });
    }
});