class CartItems extends HTMLElement {
    constructor() {
        super();

        this.cartCountDown = document.getElementById(`CartCountdown-${this.dataset.section}`)
        this.giftCardElement = document.getElementById('is-a-gift')
        this.giftCardButton = document.getElementById('cart-gift-wrapping')
        this.removeButtons = document.querySelectorAll('[data-cart-remove]')
        this.toCheckoutButton = document.getElementById('cart-checkouts')
        this.couponCodeInput = document.getElementById('cart-coupon-code')
        this.cartNoteInput = document.getElementById('cart-note')
        this.checkTerms = document.getElementById('cart_conditions')
        this.clearCartButton = document.getElementById('clear-cart-button');

        this.toCheckoutButton?.addEventListener('click', this.handleToCheckoutPage.bind(this))

        this.initClearCartButton();
        this.initCartCountdown()
        if (this.giftCardElement) this.initGiftCardElement()
        this.initGiftCardManipulation()
    }

    initClearCartButton() {
        if (!this.clearCartButton) return;

        const clearLink = this.clearCartButton;

        clearLink.addEventListener('click', async (e) => {
            e.preventDefault();
            e.stopPropagation();

            clearLink.style.display = 'none';

            try {
                await fetch('/cart/clear.js', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });

                window.location.reload();
            } catch (error) {
                console.error('Error clearing cart:', error);
                clearLink.style.display = '';
            }
        });
    }

    initGiftCardElement() {
        const isChecked = this.giftCardButton?.dataset.isChecked
        if (isChecked === 'true') {
            const variantId = this.giftCardButton?.dataset.giftId
            const giftCardRemoveButton = document.querySelector(`[data-cart-remove-id="${variantId}"]`)
            const giftCardQuantityInput = document.querySelector(`[data-cart-quantity-id="${variantId}"]`)

            this.giftCardElement.style.display = 'none'
            giftCardRemoveButton?.addEventListener('click', () => {
                this.giftCardButton.dataset.isChecked = 'false'
            })

            giftCardQuantityInput?.addEventListener('change', (e) => {
                const value = Number(e.target.value)
                if (value  <= 0) {
                    this.giftCardButton.dataset.isChecked = 'false'
                }
            })
        } else {
          this.giftCardElement.style.display = 'flex'
        }
    }

    initGiftCardManipulation() {
        if (this.giftCardButton) {
            this.giftCardButton.removeEventListener('click', this.onAddGiftCardClick?.bind(this))
            this.giftCardButton.addEventListener('click', this.onAddGiftCardClick.bind(this))
        }
    }

    onAddGiftCardClick(e) {
        e.preventDefault()
        e.stopPropagation()
        this.giftCardButton.dataset.isChecked = 'true'
    }

    async handleToCheckoutPage(e) {
        e.preventDefault()
       
        try {
            const couponCode = this.couponCodeInput?.value 
            if (couponCode) {
                localStorage.setItem('storedDiscount', couponCode)
                await fetch(`/discount/${couponCode}`)
            }
            
            const cartNote = this.cartNoteInput?.value
            if (cartNote) {
                const cartNoteBody = JSON.stringify({ note: cartNote })
                await fetch(`${routes.cart_update_url}`, {...fetchConfig(), ...{ body: cartNoteBody }})
            }

        } catch(error) {
            console.error(`Error: ${error.message}`)
        }

        let checkoutHref = this.toCheckoutButton.dataset.href;
        if (checkoutHref == null) {
            checkoutHref = `${window.routes?.root ? window.routes.root : ""}/checkout`;
        }
        
        window.location = checkoutHref;
    }

    initCartCountdown(){
        if(!this.cartCountDown) return;

        if(!this.cartCountDown.classList.contains('is-running')){
            const duration = this.cartCountDown.getAttribute('data-cart-countdown') * 60
            const element = this.cartCountDown.querySelector('.time');

            this.cartCountDown.classList.add('is-running');
            this.startTimerCartCountdown(duration, element);
        }
    }

    startTimerCartCountdown(duration, element){
        var timer = duration, minutes, seconds, text;

        var startCoundown = setInterval(() => {
            minutes = parseInt(timer / 60, 10);
            seconds = parseInt(timer % 60, 10);

            minutes = minutes < 10 ? "0" + minutes : minutes;
            seconds = seconds < 10 ? "0" + seconds : seconds;
            text = minutes + ":" + seconds;

            element.innerText = text;

            if (--timer < 0) {
                clearInterval(startCoundown);
                this.cartCountDown.remove();
            }
        }, 1000);
    }
}

customElements.define('cart-items', CartItems);
