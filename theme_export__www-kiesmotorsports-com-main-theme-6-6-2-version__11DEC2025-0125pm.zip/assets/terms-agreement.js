// Configuration: Add product tags that require terms
const RESTRICTED_TAGS = ['downpipes', 'midpipes', 'Downpipes', 'Midpipes'];

// Signature pad setup
var signatureCanvas = document.getElementById('signaturePad');
var signatureCtx = null;
var isDrawing = false;
var hasSignature = false;

function initSignaturePad() {
  if (!signatureCanvas) return;
  signatureCanvas.style.width = '100%';
  signatureCanvas.style.height = '200px';
  const rect = signatureCanvas.getBoundingClientRect();
  signatureCanvas.width = rect.width || 700;
  signatureCanvas.height = 200;

  signatureCtx = signatureCanvas.getContext('2d');
  signatureCtx.strokeStyle = '#000';
  signatureCtx.lineWidth = 2;
  signatureCtx.lineCap = 'round';

  // Mouse events
  signatureCanvas.addEventListener('mousedown', startDrawing);
  signatureCanvas.addEventListener('mousemove', draw);
  signatureCanvas.addEventListener('mouseup', stopDrawing);
  signatureCanvas.addEventListener('mouseleave', stopDrawing);

  // Touch events
  signatureCanvas.addEventListener('touchstart', startDrawing);
  signatureCanvas.addEventListener('touchmove', draw);
  signatureCanvas.addEventListener('touchend', stopDrawing);

  console.log('Signature pad initialized');
}

// Initialize on page load
initSignaturePad();

function startDrawing(e) {
  if (!signatureCtx) return;
  e.preventDefault();
  isDrawing = true;
  hasSignature = true;
  var placeholder = document.getElementById('signaturePlaceholder');
  if (placeholder) placeholder.style.display = 'none';
  const rect = signatureCanvas.getBoundingClientRect();
  const x = (e.clientX || e.touches[0].clientX) - rect.left;
  const y = (e.clientY || e.touches[0].clientY) - rect.top;
  signatureCtx.beginPath();
  signatureCtx.moveTo(x, y);
  checkFormCompletion();
}

function draw(e) {
  if (!isDrawing || !signatureCtx) return;
  e.preventDefault();
  const rect = signatureCanvas.getBoundingClientRect();
  const x = (e.clientX || e.touches[0].clientX) - rect.left;
  const y = (e.clientY || e.touches[0].clientY) - rect.top;
  signatureCtx.lineTo(x, y);
  signatureCtx.stroke();
}

function stopDrawing() {
  isDrawing = false;
}

function clearSignature() {
  if (!signatureCtx) return;
  signatureCtx.clearRect(0, 0, signatureCanvas.width, signatureCanvas.height);
  hasSignature = false;
  var placeholder = document.getElementById('signaturePlaceholder');
  if (placeholder) placeholder.style.display = 'block';
  checkFormCompletion();
}

// Check if form is complete
function checkFormCompletion() {
  const c1 = document.getElementById('check1')?.checked || false;
  const c2 = document.getElementById('check2')?.checked || false;
  const c3 = document.getElementById('check3')?.checked || false;
  const c4 = document.getElementById('check4')?.checked || false;
  const c5 = document.getElementById('check5')?.checked || false;
  const name = document.getElementById('fullName')?.value.trim() || '';
  const email = document.getElementById('termsEmail')?.value.trim() || '';
  const vehicle = document.getElementById('vehicleInfo')?.value.trim() || '';
  const submitBtn = document.getElementById('submitTerms');
  if (!submitBtn) return;

  if (c1 && c2 && c3 && c4 && c5 && name && email && vehicle && hasSignature) {
    submitBtn.classList.remove('disabled');
    submitBtn.classList.add('enabled');
    submitBtn.textContent = 'ACCEPT TERMS & PROCEED TO CHECKOUT';
  } else {
    submitBtn.classList.add('disabled');
    submitBtn.classList.remove('enabled');
    submitBtn.textContent = 'COMPLETE ALL FIELDS TO CONTINUE';
  }
}

// Add event listeners to form fields
document.getElementById('fullName')?.addEventListener('input', checkFormCompletion);
document.getElementById('termsEmail')?.addEventListener('input', checkFormCompletion);
document.getElementById('vehicleInfo')?.addEventListener('input', checkFormCompletion);
document.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.addEventListener('change', checkFormCompletion));

/* ✅ Check cart for restricted items (works for array or string tags) */
function checkCartForRestrictedItems() {
  fetch('/cart.js')
    .then(response => response.json())
    .then(async (cart) => {
      console.log('Checking cart for restricted items (by fetching product tags)...');
      let hasRestrictedItem = false;

      for (const item of cart.items) {
        if (!item.handle) continue;

        try {
          const res = await fetch(`/products/${item.handle}.js`);
          const product = await res.json();

          console.log(`🧩 Checking product: ${product.title}`);
          console.log('🏷️ Product tags:', product.tags);

          // ✅ Normalize tags to lowercase clean array
          let tagsArray = [];

          if (Array.isArray(product.tags)) {
            tagsArray = product.tags.map(t =>
              String(t).replace(/'/g, '').trim().toLowerCase()
            );
          } else if (typeof product.tags === 'string') {
            tagsArray = product.tags
              .split(',')
              .map(t => t.replace(/'/g, '').trim().toLowerCase());
          }

          // ✅ Check against restricted list
          if (
            tagsArray.some(tag =>
              RESTRICTED_TAGS.some(r => tag.includes(r.toLowerCase()))
            )
          ) {
            console.log('✅ Restricted item found by tag:', product.tags);
            hasRestrictedItem = true;
            break; // stop once one restricted product is found
          }
        } catch (err) {
          console.warn(`⚠️ Failed to fetch product info for ${item.handle}`, err);
        }
      }

      if (hasRestrictedItem && !sessionStorage.getItem('termsAccepted')) {
        console.log('⚠️ Restricted item detected → showing Terms modal');
        document.getElementById('termsModalOverlay').classList.add('active');
        setTimeout(initSignaturePad, 100);
      } else {
        console.log('ℹ️ No restricted items found.');
      }
    })
    .catch(err => console.error('Error checking cart:', err));
}

/* ✅ Generate compressed agreement image */
async function generateAgreementImage(fullName, email, vehicle, dateFormatted, signatureData) {
  const canvas = document.createElement('canvas');
  canvas.width = 600;
  canvas.height = 1200;
  const ctx = canvas.getContext('2d');

  function wrapText(text, x, y, maxWidth, lineHeight) {
    const words = text.split(' ');
    let line = '';
    for (let n = 0; n < words.length; n++) {
      const testLine = line + words[n] + ' ';
      const metrics = ctx.measureText(testLine);
      if (metrics.width > maxWidth && n > 0) {
        ctx.fillText(line, x, y);
        line = words[n] + ' ';
        y += lineHeight;
      } else {
        line = testLine;
      }
    }
    ctx.fillText(line, x, y);
    return y + lineHeight;
  }

  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = '#000';
  ctx.textAlign = 'left';
  ctx.font = 'bold 13px Arial';
  ctx.fillText('OFF-ROAD USE POLICY & EMISSIONS COMPLIANCE NOTICE', 20, 30);

  ctx.font = '11px Arial';
  let y = 55;
  const lineH = 16;
  const maxW = 560;

  const textBlocks = [
    'California Proposition 65 Warning:',
    'This product can expose you to chemicals such as lead and lead compounds, which are known to cause cancer or birth defects or other reproductive harm.',
    'For more information, visit www.P65Warnings.ca.gov.',
    '',
    'EPA / CARB Compliance & Legal Use:',
    'Under the federal Clean Air Act (42 U.S.C. §7522(a)(3)), it is illegal to modify or defeat emissions controls on public-road vehicles.',
    '',
    'Intended Use & Customer Certification:',
    'These parts are for closed-course or off-road use only.',
    '',
    'By purchasing or installing these products, you acknowledge and certify the following:'
  ];
  textBlocks.forEach(p => (y = wrapText(p, 20, y, maxW, lineH)));

  const checks = [
    '✓ I have read and understood the California Proposition 65 Warning.',
    '✓ I have read and understood the EPA/CARB Compliance Notice.',
    '✓ I understand these products are for off-road or competition use only.',
    '✓ I acknowledge it is my responsibility to comply with all emissions laws.',
    '✓ I understand using this on public roads violates the Clean Air Act.'
  ];
  checks.forEach(line => (y = wrapText(line, 40, y, maxW - 20, lineH)));

  y += 10;
  ['Date', 'Name', 'Email', 'Vehicle'].forEach((label, i) => {
    const val = [dateFormatted, fullName, email, vehicle][i];
    y = wrapText(`${label}: ${val}`, 20, y, maxW, lineH);
  });

  const sigImg = new Image();
  sigImg.src = signatureData;
  await new Promise(r => (sigImg.onload = r));
  ctx.drawImage(sigImg, 20, y + 10, 200, 60);
  ctx.font = '10px Arial';
  ctx.fillText('Digitally signed and accepted by customer.', 20, y + 85);

  const trimmed = document.createElement('canvas');
  trimmed.width = canvas.width;
  trimmed.height = y + 120;
  trimmed.getContext('2d').drawImage(canvas, 0, 0);

  let quality = 0.8;
  let dataUrl = trimmed.toDataURL('image/jpeg', quality);
  while (dataUrl.length / 1024 > 45 && quality > 0.2) {
    quality -= 0.1;
    dataUrl = trimmed.toDataURL('image/jpeg', quality);
  }

  console.log('Final size:', (dataUrl.length / 1024).toFixed(1), 'KB @quality', quality);
  return dataUrl;
}

/* ✅ Submission logic */
async function submitTerms() {
  const submitBtn = document.getElementById('submitTerms');
  if (!submitBtn.classList.contains('enabled')) return;

  submitBtn.textContent = 'GENERATING AGREEMENT...';
  submitBtn.disabled = true;

  const signatureData = signatureCanvas.toDataURL();
  const timestamp = new Date().toISOString();
  const dateFormatted = new Date().toLocaleString();
  const fullName = document.getElementById('fullName').value;
  const email = document.getElementById('termsEmail').value;
  const vehicle = document.getElementById('vehicleInfo').value;

  try {
    const imageData = await generateAgreementImage(fullName, email, vehicle, dateFormatted, signatureData);
    const cleanName = fullName.replace(/[^a-z0-9]/gi, '_');
    const emailParams = {
      customer_name: fullName,
      customer_email: email,
      customer_vehicle: vehicle,
      agreement_date: dateFormatted,
      agreement_image: imageData,
      file_name: `${cleanName}_Exhaust_Agreement.jpeg`,
      to_email: 'info@kiesmotorsports.com'
    };

    submitBtn.textContent = 'SENDING EMAIL...';
    await emailjs.send('service_zxgppr6', 'template_0y7r0op', emailParams);

    const agreementText = `
EXHAUST TERMS AGREEMENT
========================
Date: ${dateFormatted}
Name: ${fullName}
Email: ${email}
Vehicle: ${vehicle}

CERTIFICATIONS:
✓ CA PROP65 Warning Acknowledged
✓ EPA/CARB Compliance Warning Acknowledged

The customer has digitally signed this agreement.
Signature timestamp: ${timestamp}

Agreement has been emailed to Kies Motorsports with signature.

This product is for OFF-ROAD USE ONLY and may not be used on public roads or highways.
    `.trim();

    await fetch('/cart/update.js', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        attributes: {
          'Exhaust_Terms_Agreement': agreementText,
          'Customer_Name': fullName,
          'Customer_Email': email,
          'Customer_Vehicle': vehicle,
          'Agreement_Timestamp': timestamp,
          'Email_Status': 'Sent to info@kiesmotorsports.com',
          '_signature_full': signatureData
        }
      })
    });

    sessionStorage.setItem('termsAccepted', 'true');
    document.getElementById('termsModalOverlay').classList.remove('active');
    alert('✓ Terms accepted! Signed agreement image has been emailed.');
    window.location.href = '/checkout';

  } catch (err) {
    console.error('Submission error:', err);
    submitBtn.textContent = 'ACCEPT TERMS & PROCEED TO CHECKOUT';
    submitBtn.disabled = false;
    alert('There was an error sending the agreement. Please try again.');
  }
}

function closeTermsModal() {
  alert('You must accept the terms to proceed with checkout for restricted items.');
}

if (window.location.pathname.includes('/cart')) {
  checkCartForRestrictedItems();
}

document.addEventListener('click', function(e) {
  if (
    e.target.matches('[name="checkout"], .cart__checkout, .cart__checkout-button, [href="/checkout"]') ||
    e.target.closest('[name="checkout"], .cart__checkout, .cart__checkout-button, [href="/checkout"]')
  ) {
    e.preventDefault();
    checkCartForRestrictedItems();
    setTimeout(() => {
      if (!document.getElementById('termsModalOverlay').classList.contains('active')) {
        window.location.href = '/checkout';
      }
    }, 500);
  }
});
